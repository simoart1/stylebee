function order(){window.open('https://wa.me/212703655235?text='+encodeURIComponent('أرغب في طلب انصومبل صاري – أزرق ملكي
المقاس: '+document.getElementById('size').value+'
الثمن: 189 MAD'),'_blank');}